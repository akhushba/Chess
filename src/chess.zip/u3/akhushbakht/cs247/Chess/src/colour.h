#ifndef COLOUR_H
#define COLOUR_H

enum Colour {
    WHITE,
    BLACK,
    NULL_C
};

#endif 

