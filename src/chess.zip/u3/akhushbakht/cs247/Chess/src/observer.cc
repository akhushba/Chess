#include "observer.h"

void Observer::notify() {}
